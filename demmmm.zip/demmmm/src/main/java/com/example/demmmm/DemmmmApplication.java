package com.example.demmmm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemmmmApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemmmmApplication.class, args);
	}

}
