package com.example.demmmm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemmmmApplicationTests {

	@Test
	void contextLoads() {
	}

}
